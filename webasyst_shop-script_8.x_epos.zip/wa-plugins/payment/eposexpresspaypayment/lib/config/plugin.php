<?php
return array(
    'name'        => 'Эксресс платежи: E-POS',
    'description' => 'Прием платежей через E-POS',
    'icon'        => 'img/icon.svg',
    'logo'        => 'img/logo.png',
    'vendor'      => 'webasyst',
    'version'     => '1.0.0',
);